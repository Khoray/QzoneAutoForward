# cqtest

## How to start

1. generate project using `nb create` .
2. writing your plugins under `cqtest/plugins` folder.
3. run your bot using `nb run` .
