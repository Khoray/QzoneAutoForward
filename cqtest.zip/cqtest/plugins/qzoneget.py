import requests
import json
import re

async def get_shuo(qnum):
    
    url = f"https://user.qzone.qq.com/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_homepage_msg?owneruin={qnum}&start=0&num=10&code_version=1&need_private_comment=1&format=jsonp&g_tk=118307533"
    #url = "https://user.qzone.qq.com/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_homepage_msg?owneruin=2213622817"
    data = "source=aiostar"

    headers = {
        # ':authority': 'user.qzone.qq.com',
        # ':method': 'GET',
        # ':path': '/2213622817?source=aiostar',
        # ':scheme': 'https',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'cache-control': 'max-age=0',
        'cookie': 'RK=o2rEk5kvRh; ptcz=00e8c900d1b4bf0300334beff3e960949eddc365e5e6a5babad615d6f95fce68; pgv_pvid=9773617024; QZ_FE_WEBP_SUPPORT=1; eas_sid=L1c6h2D3N3Z2K3U6e3y2b2L718; __Q_w_s_hat_seed=1; __Q_w_s__QZN_TodoMsgCnt=1; o_cookie=1251433731; pac_uid=1_1251433731; luin=o1251433731; lskey=000100009bbd595d07bf7b46ade38076f914cf8118eedde56259599f3d014b2f6740ac4ab7a1352d49520921; randomSeed=889902; ptui_loginuin=1251433731; pt_sms_phone=177******28; uin_cookie=o1251433731; ied_qq=o1251433731; _qpsvr_localtk=1625669308185; Loading=Yes; pgv_info=ssid=s8319313731; cpu_performance_v8=8; zzpaneluin=; zzpanelkey=; uin=o1251433731; skey=@IW6DEVUpX; p_uin=o1251433731; pt4_token=iDMtQIZLE8hpdsTWuI8ekxgB5e2Kb3s7ar8BwkO4QOs_; p_skey=t2fD5bdY*8MaENdFMC*sq*UuZazm7*ZKlLAiCK5TEoQ_; rv2=8032CC030410F51DF6406E46DF936FFF3E24DB08DA72FD6F70; property20=3AAE0316474402245BA6FB4A4203AB66D36DE07907E19C0AE81A17DA2906F2AEF12D9C2E030628FD',
        'if-modified-since': 'Thu, 08 Jul 2021 08:29: 02 GMT',
        'sec-ch-ua': '"Not;A Brand";v="99", "Microsoft Edge";v="91", "Chromium";v="91"',
        'sec-ch-ua-mobile': '?0',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.64'
    }


    response = requests.get(headers = headers, url = url, data = data)

    dp = json.loads(re.findall(r"_Callback\(({.*})\)", response.text)[0])
    ret = []
    for i in dp['result']['posts']:
        ret.append((i['content'], i['create_time']))

    return ret
